// ====================================================
// SoilWatch ESP32
// Auto Connect ke ESP32
// IP ESP32 : 10.170.65.143
// ====================================================

const ESP32_IP = "10.170.65.143";

const ipInput = document.getElementById('ipInput');
const connectBtn = document.getElementById('connectBtn');
const connHint = document.getElementById('connHint');
const connDot = document.getElementById('connDot');
const connLabel = document.getElementById('connLabel');

const humidityValue = document.getElementById('humidityValue');
const lcdLine1 = document.getElementById('lcdLine1');
const lcdLine2 = document.getElementById('lcdLine2');
const statusPlate = document.getElementById('statusPlate');
const statusText = document.getElementById('statusText');

const ledRed = document.getElementById('ledRed');
const ledAmber = document.getElementById('ledAmber');
const ledGreen = document.getElementById('ledGreen');

const needle = document.getElementById('needle');
const logList = document.getElementById('logList');
const sparklinePoly = document.getElementById('sparklinePoly');

let pollTimer = null;

const history = [];
const MAX_HISTORY = 20;

// =======================
// GAUGE
// =======================

const GAUGE_CX = 140;
const GAUGE_CY = 150;
const GAUGE_R = 110;
const NEEDLE_LEN = 95;

function polarPoint(cx, cy, r, angleDeg) {
  const rad = (angleDeg - 90) * Math.PI / 180;

  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad)
  };
}

function percentToAngle(p) {
  const clamped = Math.max(0, Math.min(100, p));
  return -90 + (clamped / 100) * 180;
}

function describeArc(start, end) {

  const a0 = percentToAngle(start);
  const a1 = percentToAngle(end);

  const p0 = polarPoint(GAUGE_CX, GAUGE_CY, GAUGE_R, a0);
  const p1 = polarPoint(GAUGE_CX, GAUGE_CY, GAUGE_R, a1);

  return `M ${p0.x} ${p0.y} A ${GAUGE_R} ${GAUGE_R} 0 0 1 ${p1.x} ${p1.y}`;
}

document.getElementById('zoneRed')
.setAttribute('d', describeArc(0, 40));

document.getElementById('zoneAmber')
.setAttribute('d', describeArc(40, 60));

document.getElementById('zoneGreen')
.setAttribute('d', describeArc(60, 100));

function setNeedle(percent) {

  const angle = percentToAngle(percent);

  const tip = polarPoint(
    GAUGE_CX,
    GAUGE_CY,
    NEEDLE_LEN,
    angle
  );

  needle.setAttribute('x2', tip.x);
  needle.setAttribute('y2', tip.y);
}

// =======================
// STATUS
// =======================

function applyStatus(status, humidity) {

  ledRed.classList.remove('on');
  ledAmber.classList.remove('on');
  ledGreen.classList.remove('on');

  if (status === "BASAH")
    ledRed.classList.add('on');

  if (status === "BAIK")
    ledAmber.classList.add('on');

  if (status === "KERING")
    ledGreen.classList.add('on');

  statusText.textContent = status;

  lcdLine1.textContent =
    "Kelembapan Tanah " + status;

  lcdLine2.textContent =
    "Presentasi: " +
    humidity.toFixed(1) +
    "%";
}

// =======================
// LOG
// =======================

function pushHistory(value) {

  history.push({
    time: new Date(),
    value: value
  });

  if (history.length > MAX_HISTORY)
    history.shift();

  renderLog();
  renderSparkline();
}

function renderLog() {

  logList.innerHTML = "";

  [...history]
    .reverse()
    .forEach(item => {

      const li =
      document.createElement("li");

      li.innerHTML =
      `<span>${item.time.toLocaleTimeString()}</span>
       <span>${item.value.toFixed(1)}%</span>`;

      logList.appendChild(li);
    });
}

function renderSparkline() {

  if (history.length < 2) return;

  const points = history.map((item, index) => {

    const x =
      (index / (history.length - 1))
      * 300;

    const y =
      60 - ((item.value / 100) * 60);

    return `${x},${y}`;

  }).join(" ");

  sparklinePoly.setAttribute(
    "points",
    points
  );
}

// =======================
// KONEKSI ESP32
// =======================

function setConnected() {

  connDot.className = "dot online";
  connLabel.textContent = "Terhubung";
}

function setDisconnected() {

  connDot.className = "dot offline";
  connLabel.textContent = "Terputus";
}

async function getData() {

  try {

    const response =
      await fetch(
        `http://${ESP32_IP}/data`
      );

    const data =
      await response.json();

    const humidity =
      Number(data.humidity);

    humidityValue.textContent =
      humidity.toFixed(1);

    setNeedle(humidity);

    applyStatus(
      data.status,
      humidity
    );

    pushHistory(humidity);

    setConnected();

    connHint.textContent =
      "ESP32 berhasil terhubung";

  }
  catch(error) {

    console.log(error);

    setDisconnected();

    connHint.textContent =
      "Gagal terhubung ke ESP32";
  }
}

function startPolling() {

  getData();

  pollTimer =
    setInterval(
      getData,
      2000
    );
}

// =======================
// AUTO CONNECT
// =======================

window.onload = function() {

  ipInput.value = ESP32_IP;

  startPolling();
};

connectBtn.addEventListener(
  'click',
  startPolling
);